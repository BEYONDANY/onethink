<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
<title></title>
</head>
<body>
<?php echo ($result["id"]); ?>--<?php echo ($result["data"]); ?>
</body>
</html>